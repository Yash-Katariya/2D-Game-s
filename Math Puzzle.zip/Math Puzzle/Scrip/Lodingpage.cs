using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class Lodingpage : MonoBehaviour
{
    //public GameObject Intro;
    //bool isPrograssRunning = false;
    public float WTime = 10.0f;

    public void Start()
    {
        StartCoroutine(MovetoLoding());
    } 
    public IEnumerator MovetoLoding()
    {
        yield return new WaitForSeconds(WTime);
        //Intro.SetActive(false);
        SceneManager.LoadScene("Mathpuzzle");
    }
}