using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelOne : MonoBehaviour
{
    public Text Numbertext;

    public void Number(string Value)
    { 
        Numbertext.text += Value;
    }
    public void IcnoRemove()
    {
        if (Numbertext.text.Length > 0)
        {
            Numbertext.text = Numbertext.text.Remove(Numbertext.text.Length - 1, 1);
        }
    }
}