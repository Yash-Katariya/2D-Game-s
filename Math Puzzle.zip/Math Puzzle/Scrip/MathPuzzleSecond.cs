using System.Collections;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MathPuzzleSecond : MonoBehaviour
{
    public GameObject SecondPrefab;
    public Transform SecondPrefabTransform;

    public void OnEnable()
    {
        int Number = 29;
        for (int i = 29; i <= 56; i++)
        { 
            GameObject g = Instantiate(SecondPrefab, SecondPrefabTransform);
            TMP_Text T = g.GetComponentInChildren<TMP_Text>();
            Button b = g.GetComponent<Button>();

            if (Number == 28)
            { 
                
            }
            else
            {
                T.text = i.ToString();
            }
            Number++;
        }
    }    
}
