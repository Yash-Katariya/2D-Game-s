using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Back : MonoBehaviour
{
    public GameObject Level, Play;

    public void GotoLevelone()
    { 
        Level.SetActive(false);
        Play.SetActive(true);
    }
    public void GotonextScenes(string Next)
    {
        SceneManager.LoadScene(Next);
    }
}