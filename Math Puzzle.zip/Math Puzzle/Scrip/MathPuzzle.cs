using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MathPuzzle : MonoBehaviour
{
    public GameObject ButtonPrefab;
    public Transform ButtonTfrom;

    public void OnEnable()
    {
        int Num = 1;
        for (int i = 1; i <= 28; i++)
        { 
            GameObject G = Instantiate(ButtonPrefab, ButtonTfrom);
            TMP_Text Text = G.GetComponentInChildren<TMP_Text>();
            Button B = G.GetComponent<Button>();

            if (Num == 0)
            {

            }
            else
            { 
                Text.text = i.ToString();
            }
            Num++;
        }
    }    
}